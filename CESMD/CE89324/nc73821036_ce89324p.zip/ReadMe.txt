Note: 

Channel 17, 18 and 20 have been reprocessed because of issues with the accelerometers